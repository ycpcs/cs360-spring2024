/* Utility function to create a random D[] array of length n */
void make_array(int D[], int n, int range)
{
	int i;
	D[0] = n;
	for (i = 1; i <= n; i++)
	{
		D[i] = rand() % range + 1;
	}
}

/* Utility function to copy D[] -> A[] */
void copy_array(int A[], int D[], int n)
{
	int i;
	for (i = 0; i <= n; i++)
	{
		A[i] = D[i];
	}
}

/* Utility function to print sorted A[] array */
void print_array(int A[], int n)
{
	int i;
	for (i = 1; i <= n; i++)
	{
		printf("%i ", A[i]);
	}
	printf("\n");
}

/* Utility function to check if A[] array is increasing */
bool checkSorted(int A[], int n) {
    for (int i = 1; i < n; i++) {
        if (A[i] > A[i+1]) {
            return false;
        }
    }
    return true;
}

