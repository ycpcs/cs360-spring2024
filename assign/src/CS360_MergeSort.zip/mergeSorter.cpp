// CS360 Merge Sort
// Spring 2024

// So we can use scanf in Visual Studio
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Utilities.h"

#define INFINITY 32769
#define NUM_AVG 1              // Number of sorting runs to average
#define MAX_ELEMENTS 65537      // Maximum number of elements in input array
#define HIGH_RANGE 32768        // Maximum value for large input range
#define LOW_RANGE 1024			// Maximum value for small input range
#define MAX_RUNS 1             // Maximum number of 2^i input sizes to run
#define NUM_SORTS 1             // Number of sorting algorithms

int merge_sort(int A[], int p, int r);
void merge(int A[], int p, int q, int r);
int count;

int main(void)
{
	int A[MAX_ELEMENTS],D[MAX_ELEMENTS];
	int n,i,j,k;
	double counter[NUM_SORTS][MAX_RUNS][2];

	srand(0);
	// Initialize counter array
	for (k=0; k<NUM_SORTS; k++)
	{
		for (i=0; i<MAX_RUNS; i++)
		{
			counter[k][i][0] = 0.0;
			counter[k][i][1] = 0.0;
		}
	}

	// Set number of elements in initial array and start counter
	n = 16;
	i = 0;

	// Loop for each input size
	while ((n <= MAX_ELEMENTS) && (i < MAX_RUNS))
	{
		// Loop with random input arrays of fixed size to average results
		for (j = 0; j < NUM_AVG; j++)
		{
			for (k = 0; k < NUM_SORTS; k++) {
				// Generate random array of size n for small range
				make_array(D, n, LOW_RANGE);

				// Run sort
				copy_array(A, D, n);
				//print_array(A);
				count = 0;
				counter[k][i][0] += (merge_sort(A, 1, n) / ((double)NUM_AVG));
				if (!checkSorted(A, n)) {
				    printf("Sort incorrect!\n");
				    exit(0);
				}
				//print_array(A);

				// Generate random array of size n for large range
				make_array(D, n, HIGH_RANGE);

				// Run sort
				copy_array(A, D, n);
				//print_array(A);
				count = 0;
				counter[k][i][1] += (merge_sort(A, 1, n) / ((double)NUM_AVG));
                if (!checkSorted(A, n)) {
                    printf("Sort incorrect!\n");
                    exit(0);
                }
				//print_array(A);
			}
		}

		// Double number of input elements for next run
		n *= 2;
		i++;
	}

	/* Print avg runtime results */
	FILE *fp = fopen("mergeOutput.csv","w");
	if (fp != NULL) {
		n = 16;
		printf("%-20s %-20s %-20s\n", "n", "Merge-1024", "Merge-32768");
		fprintf(fp,"%-20s, %-20s, %-20s\n", "n", "Merge-1024", "Merge-32768");
		printf("-------------------- -------------------- --------------------\n");
		for (j = 0; j < i; j++)
		{
			printf("%-20d,", n);
			fprintf(fp, "%-20d,", n);
			for (k = 0; k < NUM_SORTS; k++)
			{
				if (k == NUM_SORTS - 1) {
					// No comma for last piece
					printf("%-20d,%-20d", (int)counter[k][j][0], (int)counter[k][j][1]);
					fprintf(fp, "%-20d,%-20d", (int)counter[k][j][0], (int)counter[k][j][1]);
				}
				else {
					printf("%-20d,%-20d,", (int)counter[k][j][0], (int)counter[k][j][1]);
					fprintf(fp, "%-20d,%-20d,", (int)counter[k][j][0], (int)counter[k][j][1]);
				}
			}
			printf("\n");
			fprintf(fp,"\n");
			n *= 2;
		}
		fclose(fp);
	} else {
		printf("Unable to open output file - Make sure it is not open in Excel\n");
	}

//	int key;
//	printf("Enter a value to quit");
//	scanf("%d",&key);
	
	return 0;
}


/* Merge sort routine(s) */
int merge_sort(int A[], int p, int r)
{
    int q;

    /* TODO: add MERGE-SORT() code */


    return count;
}

void merge(int A[], int p, int q, int r)
{
	int *L, *R;
	int nL = 0, nR = 0;
	int i, j, k;

	nL = q - p + 1;
	count++;
	nR = r - q;
	count++;

	L = (int*)malloc((nL) * sizeof(int));
	R = (int*)malloc((nR) * sizeof(int));
	count++;

	/* TODO: add MERGE() code */


    free(L);
    free(R);

    return;
}
